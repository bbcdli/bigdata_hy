package eu.stratosphere.tutorial.task1;
import java.io.IOException;
import java.util.HashSet;
import java.util.StringTokenizer;
import java.util.Set;

import eu.stratosphere.pact.common.stubs.MapStub;
import eu.stratosphere.pact.common.stubs.Collector;
import eu.stratosphere.pact.common.type.PactRecord;
import eu.stratosphere.pact.common.type.base.PactString;
import eu.stratosphere.pact.common.type.base.PactInteger;
/***********************************************************************************************************************
 *
 * Copyright (C) 2013 by the Stratosphere project (http://stratosphere.eu)
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 *
 **********************************************************************************************************************/
import eu.stratosphere.tutorial.util.Util;


/**
 * Autor: HYL
 * This mapper is part of the document frequency computation.
 * <p>
 * The document frequency of a term is the number of documents it occurs in. If
 * a document contains a term three times, it is counted only once for this
 * document. But if another document contains the word as well, the overall
 * frequency is two.
 * <p>
 * Example:
 * 
 * <pre>
 * Document 1: "Big Big Big Data"
 * Document 2: "Hello Big Data"
 * </pre>
 * 
 * The document frequency of "Big" is 2, because it appears in two documents
 * (even though it appears four times in total). "Hello" has a document
 * frequency of 1, because it only appears in document 2.
 * <p>
 * The map method will be called independently for each document.
 * @param <PactInteger>
 */
public class DocumentFrequencyMapper extends MapStub {

	// ----------------------------------------------------------------------------------------------------------------

	/**
	 * Splits the document into terms and emits a PactRecord (term, 1) for each
	 * term of the document.
	 * <p>
	 * Each input document has the format "docId, document contents".
	 * <p>
	 * Example:
	 * 
	 * <pre>
	 * 1,Gartner's definition (the 3Vs) is still widely used
	 * </pre>
	 * 
	 * The document ID of the document is 1 (start of line before the comma).
	 * The terms to be extracted are:
	 * <ul>
	 * <li>gartner</li>
	 * <li>s</li>
	 * <li>definition</li>
	 * <li>3vs</li>
	 * <li>still</li>
	 * <li>widely</li>
	 * </ul>
	 * Note that the stop words "the" and "is" have been removed and everything
	 * has been lower cased.
	 * 
	 * You need to do the following in the Mapper: 
	 * (1)split the input line so that only alphanumerical words are accepted. (ok)
	 *  "^[a-zA-Z0-9]*$" 
	 * (2) Remember to remove the document id. (ok, AsciiUtils.replaceNonWordChars(.., ' ')
	 * 
	 * (3), check if the individual terms are in the HashSet (Util.STOP_WORDS)
	 * of stopwords. You do not need to do additional extra checks because we
	 * already checked the input.
	 * 
	 * (4) use a HashSet to check if the word already occured for the given
	 * document. Remember, count each word only once here.
	 * 
	 * (5) emit all words with a frequency count of 1. Use a PactRecord with two
	 * fields. 
	 * 
	 * (6) Set the word as the first field and the count (always 1) as
	 * the second field. 
	 * 
	 * (7) use the build-in datatypes for String and int
	 * (PactString and PactInteger). 
	 * 
	 * (8) Use the output collector (second
	 * argument of map()) to emit the PactRecord
	 * 
	 * 
	 * (9) Use the provided main() method to test your code.
	 * 
	 * 
	 * 
	 * @throws IOException
	 */
//	PactInteger a = new PactInteger(1);
	@Override
	public void map(PactRecord record, Collector<PactRecord> collector)
			throws IOException {
		// Document with format "docId, document contents", Document 1: "Big Big Big Data"
		String document = record.getField(0, PactString.class).toString();

		// Implement your solution here
		// Replace all non word characters (here ',!:-)') with space
		document = document.replaceAll("\\W", " ");
		// Replace all numbers with space
		document = document.replaceAll("\\P{L}", " ");
		// set to lower case as required
		document = document.toLowerCase();
		Set<String> stopwordset = new HashSet<String>(Util.STOP_WORDS);
		Set<String> duplset = new HashSet<String>();
        StringTokenizer tokenizer = new StringTokenizer(document);
	    while (tokenizer.hasMoreElements()) {
	    	String element = (String) tokenizer.nextElement();
	    	if(!stopwordset.contains(element) && ! duplset.contains(element)){
	    		System.out.println(element);
	    	PactRecord p = new PactRecord();
	    	p.setField(0, new PactString(element));
	    	p.setField(1, new PactInteger(1));
	    	collector.collect(p);
	    	}
	    	duplset.add(element);
	    }
	}
}
